package br.com.jcavi.mbean;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import br.com.jcavi.entities.Essentia;
import br.com.jcavi.persistence.JPAUtil;

@ManagedBean
public class EssentiaMBean {

	private Essentia essentia;
	private List<Essentia> essentias;
	
	public EssentiaMBean() {
		essentia = new Essentia();
		consultar();
	}
	
	public Essentia getEssentia() {
		return essentia;
	}

	public List<Essentia> getEssentias() {
		return essentias;
	}
	
	public void setEssentia(Essentia essentia) {
		this.essentia = essentia;
	}

	public void salvar() {
		EntityManager em = JPAUtil.getEntityManager();
		em.getTransaction().begin();
		em.persist(essentia);
		em.getTransaction().commit();
		em.close();
		essentia = new Essentia();
		consultar();
	}	
	
	private void consultar() {
		EntityManager em = JPAUtil.getEntityManager();
		Query q = em.createQuery("select a from Essentia a", Essentia.class);
		this.essentias = q.getResultList();
		em.close();
	}
	
	public void excluir(Essentia essentia) {
		
		EntityManager em = JPAUtil.getEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		essentia = em.merge(essentia);
		em.remove(essentia);
		tx.commit();
		em.close();
	}
	
	public void alterar() {
		
		System.out.println(essentia.getId());
		System.out.println(essentia.getNome());
		System.out.println(essentia.getTelefone());
		System.out.println(essentia.getEmail());
		
		EntityManager em = JPAUtil.getEntityManager();
		em.getTransaction().begin();
		
		try {
			Essentia registroDetached = em.find(Essentia.class, essentia.getId());
			System.out.println(registroDetached.getId());
			System.out.println(registroDetached.getNome());
			System.out.println(registroDetached.getTelefone());
			System.out.println(registroDetached.getEmail());	
			
			em.detach(registroDetached);

		} catch (NullPointerException e) { 
			System.out.println("Objeto n�o Localizado");			
		} finally {
			System.exit(0);
		}
					
		Essentia registroGerenciado = em.find(Essentia.class, essentia.getId());
		System.out.println(registroGerenciado.getId());
		System.out.println(registroGerenciado.getNome());
		System.out.println(registroGerenciado.getTelefone());
		System.out.println(registroGerenciado.getEmail());
		
		registroGerenciado.setNome(essentia.getNome());						
		registroGerenciado.setTelefone(essentia.getTelefone());						
		registroGerenciado.setEmail(essentia.getEmail());						
		
		em.merge(registroGerenciado);	
		em.getTransaction().commit();
		em.close();
		
		consultar();
	}
}
